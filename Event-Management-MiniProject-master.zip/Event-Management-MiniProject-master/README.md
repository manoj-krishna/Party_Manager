# Event-Management-MiniProject
this is a file structure project on booking event and retriving info using b-tree
